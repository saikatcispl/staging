import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landing-page-content',
  templateUrl: './landing-page-content.component.html',
  styleUrls: ['./landing-page-content.component.css']
})
export class LandingPageContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
